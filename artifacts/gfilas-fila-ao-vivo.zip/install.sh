#!/usr/bin/env bash
set -euo pipefail
cd /opt/gfilas
payload=$(cd "$(dirname "$0")" && pwd)
backup="/var/lib/gfilas/backup-fila-$(date +%Y%m%d-%H%M%S).tar.gz"
existing=()
for file in app/routes.py app/templates/chamar.html app/templates/_chamar_fila.html app/static/js/chamar-live.js tests/test_painel_events.py; do
  if [ -f "$file" ]; then existing+=("$file"); fi
done
tar -czf "$backup" "${existing[@]}"
rollback() {
  tar -xzf "$backup" -C /opt/gfilas
  sudo systemctl restart gfilas
  echo "Atualizacao falhou; arquivos anteriores restaurados."
}
trap rollback ERR
mkdir -p app/static/js tests
cp "$payload/app/routes.py" app/routes.py
cp "$payload/app/templates/"*.html app/templates/
cp "$payload/app/static/js/chamar-live.js" app/static/js/
cp "$payload/tests/test_painel_events.py" tests/
.venv/bin/python -m unittest discover -s tests -v
sudo systemctl restart gfilas
curl --retry 10 --retry-connrefused --retry-delay 2 --fail --silent --show-error   -o /dev/null -w 'Fila: HTTP %{http_code}\n' 'http://127.0.0.1:8080/chamar?fragment=fila'
trap - ERR
echo "Fila automatica instalada. Backup: $backup"
